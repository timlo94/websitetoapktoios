/**
 * CDDUA Community Portal Core UI Logic
 */
document.addEventListener('DOMContentLoaded', () => {
  // Tab navigation
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  window.switchTab = function(targetTabId) {
    tabBtns.forEach(btn => {
      if (btn.dataset.tab === targetTabId) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    tabContents.forEach(content => {
      if (content.id === `tab-${targetTabId}`) {
        content.classList.add('active');
      } else {
        content.classList.remove('active');
      }
    });

    // Re-initialize Lucide icons if new DOM elements became visible
    if (window.lucide) {
      lucide.createIcons();
    }
  };

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      switchTab(btn.dataset.tab);
    });
  });

  // Like button interactivity
  window.toggleLike = function(btn) {
    const countSpan = btn.querySelector('.count');
    let count = parseInt(countSpan.textContent, 10);

    if (btn.classList.contains('liked')) {
      btn.classList.remove('liked');
      countSpan.textContent = count - 1;
    } else {
      btn.classList.add('liked');
      countSpan.textContent = count + 1;
      // Trigger micro-bounce animation
      btn.style.transform = 'scale(1.2)';
      setTimeout(() => btn.style.transform = '', 200);
    }
  };

  // Test interactive animation
  window.triggerTestAnimation = function() {
    const heroCard = document.querySelector('.hero-card');
    heroCard.style.transition = 'all 0.4s ease';
    heroCard.style.transform = 'scale(1.02)';
    heroCard.style.boxShadow = '0 0 40px rgba(0, 242, 254, 0.4)';
    
    setTimeout(() => {
      heroCard.style.transform = '';
      heroCard.style.boxShadow = '';
    }, 400);

    if (window.onCDDUAUpdate) {
      window.onCDDUAUpdate('v_test_demo', 'Triggered local hot-reload simulation in Community Portal!');
    }
  };

  // Fetch initial diagnostic data from backend API if available
  fetch('/api/status')
    .then(r => r.json())
    .then(data => {
      if (data && data.merkleRoot) {
        const diagHash = document.getElementById('diag-hash');
        const diagVer = document.getElementById('diag-ver');
        const diagPubKey = document.getElementById('diag-pubkey');
        
        if (diagHash) diagHash.textContent = data.merkleRoot.substring(0, 24) + '...';
        if (diagVer) diagVer.textContent = data.version;
        if (diagPubKey) diagPubKey.textContent = data.publicKeyHex || 'Verified Hardcoded Ed25519 PubKey';
      }
    })
    .catch(err => console.log('[UI] Offline mode - diagnostics loaded from defaults.'));
});
